// JavaScript Document
function update(elem)
{
	//Si lélément est actif, terminer
	if (elem.classList.contains("active")) return;
	// Défini la variable, Récupère le contenu de la class CSS concernée
	var active = document.querySelector(".active");
	// Efface le dernier block actif, ID+active+concaténée 
	document.getElementById(active.id + "_p").style.display = "none"; active.classList.remove("active");
	// Affiche le block actif, selon ID+active+concaténée
	document.getElementById(elem.id + "_p").style.display = "block";
	//Bascule propriété CSS sur l'élément actif
	elem.classList.add("active");
}